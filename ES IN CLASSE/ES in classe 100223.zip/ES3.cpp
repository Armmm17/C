/*
Scrivere un programma che chieda 4 numeri int, ne calcoli la media, la
memorizzi in una variabile float e la visualizzi con 2 decimali.
*/

#include<stdio.h>

int main(){
	int num1, num2, num3, num4;
	double media;
	
	printf("Inserisci il primo numero: ");
	scanf("%d", &num1);
	printf("Inserisci il secondo numero: ");
	scanf("%d", &num2);
	printf("Inserisci il terzo numero: ");
	scanf("%d", &num3);
	printf("Inserisci il quarto numero: ");
	scanf("%d", &num4);
	
	media = ((double)num1+(double)num2+(double)num3+(double)num4)/4;
	printf("La media �': %.2f \n", media);
	return 0;

	
}
