#include<stdio.h>

/*
Scrivere un programma che chieda un valore double e lo visualizzi con le 3
specifiche di conversione %f, %e e %g.
*/
int main(){
	double val;
	printf("Inserisic il valore: ");
	scanf("%lf", &val);
	printf("\nNumero: %f", val);
	printf("\nNumero: %e", val);
	printf("\nNumero: %g", val);
	return 0;
}
