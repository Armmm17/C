#include<stdio.h>

int main(){
	double a, b, c, d, somma, media;
	printf("Inserisci il primo numero: ");
	scanf("%lf\n", &a);
	printf("Inserisci il secondo numero: ");
	scanf("%lf\n", &b);
	printf("Inserisci il terzo numero: ");
	scanf("%lf\n", &c);
	printf("Inserisci il quarto numero: ");
	scanf("%lf\n", &d);
	
	media = (a+b+c+d)/4;
	printf("La media �': %.2f \n", media);
	return 0;
}
